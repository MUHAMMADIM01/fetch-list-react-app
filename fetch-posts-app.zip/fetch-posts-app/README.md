# Fetch Posts App

This is a simple React application that fetches a list of posts from a public API and displays them using a reusable `ListComponent`.

## Features

- Functional components with React 18+.
- Fetches data from [JSONPlaceholder](https://jsonplaceholder.typicode.com/posts).
- Reusable `ListComponent`.
- Handles loading and error states.
- Styled with basic semantic HTML and inline styles.

## Technologies Used

- React (via Vite)
- JavaScript (ES6+)
- Fetch API

## How to Run

1. Clone this repository:

```bash
git clone https://github.com/yourusername/fetch-posts-app.git
cd fetch-posts-app
```

2. Install dependencies:

```bash
npm install
```

3. Run the development server:

```bash
npm run dev
```

## Project Structure

```
fetch-posts-app/
├── public/
├── src/
│   ├── components/
│   │   └── ListComponent.jsx
│   ├── App.jsx
│   └── main.jsx
├── index.html
└── package.json
```

## License

This project is licensed under the MIT License.